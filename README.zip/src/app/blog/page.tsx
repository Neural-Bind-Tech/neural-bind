import UnderConstruction from '@/components/shared/Reuse/UnderWork';
import React from 'react';

const BlogPage = () => {
    return (
        <>
            <UnderConstruction />
        </>
    );
};

export default BlogPage;