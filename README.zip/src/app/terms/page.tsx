import UnderConstruction from '@/components/shared/Reuse/UnderWork';
import React from 'react';

const TermsPage = () => {
    return (
        <>
            <UnderConstruction />
        </>
    );
};

export default TermsPage;