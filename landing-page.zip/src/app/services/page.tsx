import UnderConstruction from '@/components/shared/Reuse/UnderWork';
import React from 'react';

const Services = () => {
    return (
        <>
            <UnderConstruction />
        </>
    );
};

export default Services;