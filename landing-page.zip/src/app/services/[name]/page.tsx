import UnderConstruction from '@/components/shared/Reuse/UnderWork';
import React from 'react';

const SingleService = () => {
    return (
        <>
            <UnderConstruction />
        </>
    );
};

export default SingleService;